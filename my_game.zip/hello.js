var width = 800;
var height = 600;
var game = new Phaser.Game(width,height,Phaser.AUTO);

var TEST = {
    preload: function() {
        game.load.image('player','Assets/basketball.png')
        game.load.image('floor','Assets/floor.png')
    },
    create: function() {
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.physics.arcade.gravity.y = 2000;


        this.player = game.add.sprite(200,100,'player');
        this.player.scale.setTo(0.1, 0.1);
        game.physics.enable(this.player,Phaser.Physics.ARCADE);
        this.player.body.collideWorldBounds=true;

        this.floorGroup = game.add.group();
        this.floorGroup.enableBody = true;
        this.floorGroup.physicsBodyType = Phaser.Physics.ARCADE;
        for(let i=0;i<10;i++) {
            let t = this.floorGroup.create(i*32,450,'floor');      
            t.body.allowGravity = false;
            t.body.immovable = true;  
        }
    },

    
    update: function() {
        

        game.physics.arcade.collide(this.player,this.floorGroup);

        if (game.input.keyboard.isDown(Phaser.Keyboard.UP)) {
            this.player.body.velocity.y-=100;
        }
        
        if (game.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
            this.player.body.velocity.x-=10;
            if (this.player.body.velocity.x > 0)
                this.player.body.velocity.x-=20;
        }
        else if (game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
            this.player.body.velocity.x+=10;
            if (this.player.body.velocity.x < 0)
                this.player.body.velocity.x+=20;
        } else {
            this.player.body.velocity.x*=0.9;
            if(Math.abs(this.player.body.velocity.x)<=0.2)
                this.player.body.velocity.x=0;
        }
    }
}

game.state.add('TEST',TEST);
game.state.start('TEST');